package com.example.zoljak_firebase_firestore_read_write_test

data class UserMenu(
    var userName: String? = null,
    var Date: String? = null,
    var foodName: String? = null,
    var totalCal: Float? = null,
    var totalGram: Float? = null,
    var totalCarbon: Float? = null,
    var totalProtein: Float? = null,
    var totalFat: Float? = null
)
