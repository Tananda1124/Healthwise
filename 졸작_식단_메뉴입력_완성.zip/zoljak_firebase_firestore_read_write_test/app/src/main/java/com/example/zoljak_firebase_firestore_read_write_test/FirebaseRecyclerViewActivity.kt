package com.example.zoljak_firebase_firestore_read_write_test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.Toast
import com.example.zoljak_firebase_firestore_read_write_test.databinding.ActivityFirebaseRecyclerViewBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.ktx.auth
import com.google.gson.Gson
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date

class FirebaseRecyclerViewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFirebaseRecyclerViewBinding
    private lateinit var rvAdapter: FoodAdapter
    private lateinit var foodList: ArrayList<Food>
    private lateinit var selectedFoodList : ArrayList<Food>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFirebaseRecyclerViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //날짜 설정
        var date = getCurrentDate()

        // Firebase에서 모든 메뉴 값 가져오기 (원하는 값만 가져올 수 없으므로 모두 가져온 후 후처리 해준다.)
        lifecycleScope.launch {
            foodList = getDocumentMenus() as ArrayList<Food>
            setFoodAddButton(foodList)

            //검색 탭에서 유저가 선택한 메뉴 가져오기
            val food = intent.getSerializableExtra("selectedFood") as? Food

            if (food != null){
                binding.textTotalGram.text = food.foodName
                selectedFoodList = ArrayList<Food>()  // 새로운 리스트 생성
                val userFoodList = getMenuDocument()?.let { getUserFoodByDay(date, it) }
                if (userFoodList != null) {
                    selectedFoodList.addAll(userFoodList)
                }
                setupRecyclerView(selectedFoodList)
            }
            else{
                val userFoodList = getMenuDocument()?.let { getUserFoodByDay(date, it) }
                if(userFoodList != null){
                    setupRecyclerView(userFoodList)
                }
            }

        }

    }

    //Firebase에서 모든 음식 이름을 가져와 Food의 MutableList로 재가공
    private suspend fun getDocumentMenus(): MutableList<Food> {
        val foodDocument = mutableListOf<Food>()
        val db = Firebase.firestore
        try {
            val snapshot = db.collection("foods").get().await()
            if (snapshot.isEmpty) {
                foodDocument.add(Food("null food", 0, 0, 0, 0, 0))
                Log.e("getDocumentMenus", "No responds from DB..")
            } else {
                for (item in snapshot) {
                    val food = Food(
                        item.getString("foodName") ?: "",
                        item.getLong("totalCal")?.toFloat() ?: 0.0,
                        item.getLong("totalCarbon")?.toFloat() ?: 0.0,
                        item.getLong("totalFat")?.toFloat() ?: 0.0,
                        item.getLong("totalGram")?.toFloat() ?: 0.0,
                        item.getLong("totalProtein")?.toFloat() ?: 0.0
                    )
                    foodDocument.add(food)

                }
            }
        } catch (exception: Exception) {
            Log.e("getDocumentMenus", "error during get method.. : $exception")
        }
        return foodDocument
    }

    private fun setupRecyclerView(foodList: ArrayList<Food>) {
        if(foodList.isEmpty()){
            return
        }
        else {
            rvAdapter = FoodAdapter(foodList)  // 어댑터를 생성하고 설정
            binding.foodListRecyclerView.apply {
                layoutManager = LinearLayoutManager(this@FirebaseRecyclerViewActivity)
                adapter = rvAdapter
            }
        }
    }


    // 검색 탭으로 이동
    private fun setFoodAddButton(foodList: ArrayList<Food>){
        binding.foodAddButton.setOnClickListener {
            if(foodList.isNotEmpty()){
                val intent = Intent(applicationContext, SearchFoodActivity::class.java)
                var foodNameList = ArrayList<String>()
                var foodCalList = ArrayList<Float>()
                var foodGramList = ArrayList<Float>()
                var foodCarbonList = ArrayList<Float>()
                var foodProteinList = ArrayList<Float>()
                var foodFatList = ArrayList<Float>()
                for(menu in foodList) {
                    foodNameList.add(menu.foodName.toString())
                    foodCalList.add(menu.totalCal!!.toFloat())
                    foodGramList.add(menu.totalGram!!.toFloat())
                    foodCarbonList.add(menu.totalCarbon!!.toFloat())
                    foodProteinList.add(menu.totalProtein!!.toFloat())
                    foodFatList.add(menu.totalFat!!.toFloat())
                }
                intent.putExtra("foodNameList", foodNameList)
                intent.putExtra("foodCalList", foodCalList)
                intent.putExtra("foodGramList", foodGramList)
                intent.putExtra("foodCarbonList", foodCarbonList)
                intent.putExtra("foodProteinList", foodProteinList)
                intent.putExtra("foodFatList", foodFatList)
                startActivity(intent)
            }
            else{
                Toast.makeText(this,"No food data to send..", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //todo 유저 이름과 날짜별로 먹은 메뉴 가져오기
    suspend fun getMenuDocument(): ArrayList<UserMenu>?  {
        val currentUserUid = Firebase.auth.currentUser?.uid
        val menuList = ArrayList<UserMenu>()

        if (currentUserUid != null) {
            try {
                val result = Firebase.firestore.collection("userMenus")
                    .whereEqualTo("userName", currentUserUid)
                    .get()
                    .await()

                for (document in result.documents) {
                    val userMenu = document.toObject(UserMenu::class.java)
                    if (userMenu != null) {
                        menuList.add(userMenu)
                    }
                }
                return menuList  // menuList를 반환합니다.
            } catch (e: Exception) {
                // 데이터 가져오기에 실패한 경우의 처리
                Log.e("Firebase", "Error getting documents: ", e)
            }
        } else {
            // 현재 사용자가 로그인하지 않은 경우의 처리
            withContext(Dispatchers.Main) {
                Toast.makeText(this@FirebaseRecyclerViewActivity, "로그인을 진행해 주세요.", Toast.LENGTH_SHORT).show()
            }
        }
        return null  // 오류가 발생하거나 로그인하지 않은 경우 null을 반환
    }


    fun getUserFoodByDay(today: String, list: ArrayList<UserMenu>): ArrayList<Food> {
        val resultList = ArrayList<Food>()
        for (userMenu in list) {
            if (userMenu.Date != null && userMenu.Date == getCurrentDate()) {
                val food = Food(
                    foodName = userMenu.foodName,
                    totalCal = userMenu.totalCal,
                    totalGram = userMenu.totalGram,
                    totalCarbon = userMenu.totalCarbon,
                    totalProtein = userMenu.totalProtein,
                    totalFat = userMenu.totalFat
                )
                resultList.add(food)
            }
        }
        return resultList
    }

    // 날짜 데이터 생성 함수
    fun getCurrentDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd")
        return sdf.format(Date())
    }
}